<?php

return [

    'actions' => [

        'close' => [
            'label' => '닫기',
        ],

    ],

];
