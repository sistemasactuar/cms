<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Sulje',
        ],

    ],

];
