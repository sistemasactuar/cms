<?php

return [

    'messages' => [
        'copied' => 'ចម្លង',
    ],

];
