<?php

return [

    'messages' => [
        'uploading_file' => 'Chargement du fichier...',
    ],

];
