<?php

return [

    'messages' => [
        'uploading_file' => 'Notiek faila augšupielāde...',
    ],

];
