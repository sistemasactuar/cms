<?php

return [

    'messages' => [
        'copied' => 'Disalin',
    ],

];
