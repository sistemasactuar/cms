<?php

return [

    'single' => [

        'label' => 'Atjaunot',

        'modal' => [

            'heading' => 'Atjaunot :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atjaunot',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Atjaunots',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Atjaunot izvēlētos',

        'modal' => [

            'heading' => 'Atjaunot izvēlētos :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atjaunot',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Atjaunots',
            ],

        ],

    ],

];
