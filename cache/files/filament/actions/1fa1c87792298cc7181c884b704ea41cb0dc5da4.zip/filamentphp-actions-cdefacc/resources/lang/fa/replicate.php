<?php

return [

    'single' => [

        'label' => 'تکثیر',

        'modal' => [

            'heading' => 'تکثیر :label',

            'actions' => [

                'replicate' => [
                    'label' => 'تکثیر',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'رکورد تکثیر شد',
            ],

        ],

    ],

];
