<?php

return [

    'trigger' => [
        'label' => 'Үйлдэл',
    ],

];
