<?php

return [

    'single' => [

        'label' => 'تعديل',

        'modal' => [

            'heading' => 'تعديل :label',

            'actions' => [

                'save' => [
                    'label' => 'حفظ التغييرات',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'تم الحفظ',
            ],

        ],

    ],

];
