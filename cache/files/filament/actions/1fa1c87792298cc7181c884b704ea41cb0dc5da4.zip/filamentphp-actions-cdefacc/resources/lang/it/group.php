<?php

return [

    'trigger' => [
        'label' => 'Azioni',
    ],

];
