<?php

return [

    'single' => [

        'label' => 'Paparan',

        'modal' => [

            'heading' => 'Paparan :label',

            'actions' => [

                'close' => [
                    'label' => 'Tutup',
                ],

            ],

        ],

    ],

];
