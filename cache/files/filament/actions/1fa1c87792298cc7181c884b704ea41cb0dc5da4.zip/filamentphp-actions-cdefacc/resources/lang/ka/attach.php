<?php

return [

    'single' => [

        'label' => 'მიმაგრება',

        'modal' => [

            'heading' => 'ამაგრებთ :label',

            'fields' => [

                'record_id' => [
                    'label' => 'ჩანაწერი',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'მიმაგრება',
                ],

                'attach_another' => [
                    'label' => 'მიმაგრება და ახალი მიმაგრება',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'მიმაგრება',
            ],

        ],

    ],

];
