<?php

return [

    'single' => [

        'label' => 'Piespiedu kārtā dzēst',

        'modal' => [

            'heading' => 'Piespiedu kārtā dzēst :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Dzēsts',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Piespiedu kārtā dzēst izvēlētos',

        'modal' => [

            'heading' => 'Piespiedu kārtā dzēst izvēlētos :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Dzēsts',
            ],

        ],

    ],

];
