<?php

return [

    'single' => [

        'label' => '만들기',

        'modal' => [

            'heading' => ':label 만들기',

            'actions' => [

                'create' => [
                    'label' => '만들기',
                ],

                'create_another' => [
                    'label' => '계속 만들기',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => '생성 완료',
            ],

        ],

    ],

];
