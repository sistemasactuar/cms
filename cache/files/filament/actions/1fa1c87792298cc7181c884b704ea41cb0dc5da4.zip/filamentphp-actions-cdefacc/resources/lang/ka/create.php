<?php

return [

    'single' => [

        'label' => 'ახალი :label',

        'modal' => [

            'heading' => 'ქმნით :label',

            'actions' => [

                'create' => [
                    'label' => 'შექმნა',
                ],

                'create_another' => [
                    'label' => 'შექმნა და ახალი შექმნა',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'შექმნილია',
            ],

        ],

    ],

];
