<?php

return [

    'distinct' => [
        'must_be_selected' => 'Kamida bitta :attribute maydoni tanlanishi kerak.',
        'only_one_must_be_selected' => 'Faqat bitta :attribute maydonini tanlash kerak.',
    ],

];
