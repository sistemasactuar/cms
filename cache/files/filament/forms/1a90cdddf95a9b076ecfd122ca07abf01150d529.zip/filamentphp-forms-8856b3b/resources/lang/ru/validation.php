<?php

return [

    'distinct' => [
        'must_be_selected' => ' Должно быть выбрано хотя бы одно поле :attribute.',
        'only_one_must_be_selected' => 'Должно быть выбрано только одно поле :attribute.',
    ],

];
