<?php

return [

    'distinct' => [
        'must_be_selected' => 'Legalább egy :attribute mezőt ki kell választani.',
        'only_one_must_be_selected' => 'Csak egy :attribute mezőt választhatsz ki.',
    ],

];
