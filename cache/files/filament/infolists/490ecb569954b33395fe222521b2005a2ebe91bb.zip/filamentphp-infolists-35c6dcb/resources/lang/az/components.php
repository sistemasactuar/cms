<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count az göstər',
                'expand_list' => ':count daha çox göstər',
            ],

            'more_list_items' => 'və :count daha çox',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Açar',
                ],

                'value' => [
                    'label' => 'Dəyər',
                ],

            ],

            'placeholder' => 'Giriş yoxdur',

        ],

    ],

];
