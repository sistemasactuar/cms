<?php

return [

    'text_entry' => [
        'more_list_items' => 'र :count थप वस्तुहरू छन्',
    ],

];
