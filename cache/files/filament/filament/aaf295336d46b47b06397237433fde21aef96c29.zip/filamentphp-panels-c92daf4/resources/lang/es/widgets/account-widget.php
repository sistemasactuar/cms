<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Salir',
        ],

    ],

    'welcome' => 'Bienvenida/o',

];
