<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentasi',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
