<?php

return [

    'title' => 'Escriptori',

    'actions' => [

        'filter' => [

            'label' => 'Filtre',

            'modal' => [

                'heading' => 'Filtre',

                'actions' => [

                    'apply' => [

                        'label' => 'Aplicar',

                    ],

                ],

            ],

        ],

    ],

];
