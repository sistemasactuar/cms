<?php

return [

    'title' => 'مشاهده :label',

    'breadcrumb' => 'مشاهده',

    'content' => [

        'tab' => [
            'label' => 'مشاهده',
        ],

    ],

];
