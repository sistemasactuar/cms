<?php

return [

    'body' => 'Tienes cambios sin guardar. ¿Estás seguro de que quieres abandonar esta página?',

];
