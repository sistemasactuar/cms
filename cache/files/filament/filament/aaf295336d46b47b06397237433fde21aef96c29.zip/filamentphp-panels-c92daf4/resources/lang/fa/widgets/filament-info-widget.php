<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'مستندات',
        ],

        'open_github' => [
            'label' => 'گیت‌هاب',
        ],

    ],

];
