<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Log ud',
        ],

    ],

    'welcome' => 'Velkommen',

];
