<?php

return [

    'title' => '대시보드',

    'actions' => [

        'filter' => [

            'label' => '필터',

            'modal' => [

                'heading' => '필터',

                'actions' => [

                    'apply' => [

                        'label' => '적용',

                    ],

                ],

            ],

        ],

    ],

];
