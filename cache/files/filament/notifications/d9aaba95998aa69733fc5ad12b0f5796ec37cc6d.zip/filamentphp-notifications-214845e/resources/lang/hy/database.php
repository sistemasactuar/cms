<?php

return [

    'modal' => [

        'heading' => 'Ծանուցումներ',

        'actions' => [

            'clear' => [
                'label' => 'Ջնջել',
            ],

            'mark_all_as_read' => [
                'label' => 'Նշել բոլորը որպես կարդացված',
            ],

        ],

        'empty' => [
            'heading' => 'Ոչ մի ծանուցում',
            'description' => 'Խնդրում ենք ավելի ուշ կրկին ստուգել։',
        ],

    ],

];
