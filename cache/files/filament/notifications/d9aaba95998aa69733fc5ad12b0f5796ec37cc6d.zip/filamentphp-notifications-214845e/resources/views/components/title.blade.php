<h3
    {{ $attributes->class(['fi-no-notification-title text-sm font-medium text-gray-950 dark:text-white']) }}
>
    {{ $slot }}
</h3>
