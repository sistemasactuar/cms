<?php

declare(strict_types=1);

namespace Doctrine\DBAL\ArrayParameters;

use Throwable;

/** @internal */
interface Exception extends Throwable
{
}
