<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Exception;

class SchemaDoesNotExist extends DatabaseObjectNotFoundException
{
}
