CHANGELOG
=========

7.2
---

 * Add support for configuring the default action to block or allow unconfigured elements instead of dropping them

6.4
---

 * Add support for sanitizing unlimited length of HTML document

6.1
---

 * Add the component as experimental
