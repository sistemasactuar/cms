<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportLockedProperties\BaseLocked;

#[\Attribute]
class Locked extends BaseLocked
{
    //
}
